﻿#include <iostream>
#include <vector>
#include <stack>

using namespace std;

// Функция для обхода в глубину (DFS)
void dfs(const vector<vector<int>>& graph, int start) {
    int numVertices = graph.size();
    vector<bool> visited(numVertices, false);
    stack<int> s;

    // Помещаем стартовую вершину в стек
    s.push(start);
    visited[start] = true;

    cout << "DFS Order: ";

    while (!s.empty()) {
        int currentVertex = s.top();
        s.pop();
        cout << currentVertex << " ";

        // Перебираем смежные вершины и добавляем их в стек, если они ещё не посещены
        for (int neighbor = numVertices - 1; neighbor >= 0; --neighbor) {
            if (graph[currentVertex][neighbor] == 1 && !visited[neighbor]) {
                s.push(neighbor);
                visited[neighbor] = true;
            }
        }
    }

    cout << endl;
}

int main() {
    int numVertices;

    // Ввод числа вершин графа
    cout << "VVedite kol-vo vershin grafa: ";
    cin >> numVertices;

    // Ввод матрицы смежности
    vector<vector<int>> adjacencyMatrix(numVertices, vector<int>(numVertices, 0));
    cout << "VVedite matritsu smejnosti (0 ili 1):" << endl;
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numVertices; ++j) {
            cin >> adjacencyMatrix[i][j];
        }
    }

    int startVertex;

    // Ввод стартовой вершины
    cout << "VVedite startovuju vershinu: ";
    cin >> startVertex;

    // Вызов функции DFS
    dfs(adjacencyMatrix, startVertex);

    return 0;
}
